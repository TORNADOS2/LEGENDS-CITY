package Bots;

public class Constants {
    public static String TutorialBotPrefix = "!";
    public static long OWNERID = 525126007330570259l;
}
