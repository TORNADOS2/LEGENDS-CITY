package Bots;

public class Secret {
    public static String TutorialBotToken = "TOKEN";
}

