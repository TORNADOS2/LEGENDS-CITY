# TutorialBot
This is the code for my TutorialBot.

Hi! I am BooleanCube, a youtuber and game/bot developer!

To follow my TutorialBot series head over to: https://www.youtube.com/playlist?list=PLu-RmOYgdRXDYtbfKNvsBcT4CXLrgusSf

To join my discord server go to: https://discord.gg/3ZDpPyR
